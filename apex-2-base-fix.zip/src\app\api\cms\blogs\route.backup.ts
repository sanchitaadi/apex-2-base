﻿import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function GET(request: Request) {
  try {
    const supabase = await createClient();

    const { searchParams } = new URL(request.url);
    const status = searchParams.get("status");

    let query = supabase
      .from("cms_blogs")
      .select(`
        id,
        title,
        slug,
        excerpt,
        content,
        cover_image,
        gallery_images,
        status,
        published_at,
        seo_title,
        seo_description,
        display_order,
        created_at,
        updated_at
      `)
      .order("display_order", {
        ascending: true,
      })
      .order("published_at", {
        ascending: false,
        nullsFirst: false,
      })
      .order("created_at", {
        ascending: false,
      });

    if (status === "published") {
      query = query.eq("status", "published");
    }

    if (status === "draft") {
      query = query.eq("status", "draft");
    }

    const { data, error } = await query;

    if (error) {
      console.error(
        "CMS blogs database error:",
        error
      );

      return NextResponse.json(
        {
          blogs: [],
          error: error.message,
        },
        {
          status: 500,
        }
      );
    }

    return NextResponse.json({
      blogs: data || [],
    });
  } catch (error) {
    console.error(
      "CMS blogs API error:",
      error
    );

    return NextResponse.json(
      {
        blogs: [],
        error: "Unable to load blogs.",
      },
      {
        status: 500,
      }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();

    const title =
      typeof body.title === "string"
        ? body.title.trim()
        : "";

    const slug =
      typeof body.slug === "string"
        ? body.slug.trim()
        : "";

    const excerpt =
      typeof body.excerpt === "string"
        ? body.excerpt.trim()
        : null;

    const content =
      typeof body.content === "string"
        ? body.content
        : "";

    const coverImage =
      typeof body.cover_image === "string"
        ? body.cover_image.trim()
        : null;

    const galleryImages = Array.isArray(
      body.gallery_images
    )
      ? body.gallery_images.filter(
          (image: unknown) =>
            typeof image === "string" &&
            image.trim()
        )
      : [];

    const status =
      body.status === "published"
        ? "published"
        : "draft";

    const publishedAt =
      typeof body.published_at === "string" &&
      body.published_at.trim()
        ? body.published_at
        : status === "published"
          ? new Date().toISOString()
          : null;

    const seoTitle =
      typeof body.seo_title === "string"
        ? body.seo_title.trim()
        : null;

    const seoDescription =
      typeof body.seo_description === "string"
        ? body.seo_description.trim()
        : null;

    const displayOrder =
      Number.isFinite(Number(body.display_order))
        ? Number(body.display_order)
        : 0;

    if (!title) {
      return NextResponse.json(
        {
          error: "Blog title is required.",
        },
        {
          status: 400,
        }
      );
    }

    if (!slug) {
      return NextResponse.json(
        {
          error: "Blog slug is required.",
        },
        {
          status: 400,
        }
      );
    }

    if (!content.trim()) {
      return NextResponse.json(
        {
          error: "Blog content is required.",
        },
        {
          status: 400,
        }
      );
    }

    const supabase = await createClient();

    const { data, error } = await supabase
      .from("cms_blogs")
      .insert({
        title,
        slug,
        excerpt,
        content,
        cover_image: coverImage,
        gallery_images: galleryImages,
        status,
        published_at: publishedAt,
        seo_title: seoTitle,
        seo_description: seoDescription,
        display_order: displayOrder,
      })
      .select()
      .single();

    if (error) {
      console.error(
        "Create CMS blog error:",
        error
      );

      if (error.code === "23505") {
        return NextResponse.json(
          {
            error:
              "A blog with this URL slug already exists.",
          },
          {
            status: 409,
          }
        );
      }

      return NextResponse.json(
        {
          error: error.message,
        },
        {
          status: 500,
        }
      );
    }

    return NextResponse.json(
      {
        blog: data,
      },
      {
        status: 201,
      }
    );
  } catch (error) {
    console.error(
      "Create CMS blog error:",
      error
    );

    return NextResponse.json(
      {
        error: "Unable to create blog.",
      },
      {
        status: 500,
      }
    );
  }
}
