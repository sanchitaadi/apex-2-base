﻿import { NextRequest, NextResponse } from "next/server";
import { supabase } from "@/lib/supabase/server";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get("status");

    let query = supabase
      .from("blog_posts")
      .select("*")
      .order("publish_date", { ascending: false })
      .order("created_at", { ascending: false });

    if (status) {
      query = query.eq("status", status);
    }

    const { data, error } = await query;

    if (error) {
      console.error("BLOG API ERROR:", error);

      return NextResponse.json(
        {
          blogs: [],
          error: error.message,
        },
        { status: 500 }
      );
    }

    const blogs = (data || []).map((blog: any) => ({
      ...blog,

      image_url:
        blog.cover_image_url ||
        blog.image_url ||
        blog.cover_image ||
        blog.featured_image ||
        null,

      cover_image:
        blog.cover_image_url ||
        blog.cover_image ||
        null,

      published_at:
        blog.publish_date ||
        blog.published_at ||
        blog.created_at ||
        null,

      author:
        blog.author_name ||
        blog.author ||
        null,
    }));

    return NextResponse.json(
      { blogs },
      {
        headers: {
          "Cache-Control": "no-store",
        },
      }
    );
  } catch (error) {
    console.error("CMS BLOGS ERROR:", error);

    return NextResponse.json(
      {
        blogs: [],
        error:
          error instanceof Error
            ? error.message
            : "Unable to load blogs",
      },
      { status: 500 }
    );
  }
}
