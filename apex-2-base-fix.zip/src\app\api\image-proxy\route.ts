﻿import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  try {
    const url = request.nextUrl.searchParams.get("url");

    if (!url) {
      return new NextResponse("Missing image URL", {
        status: 400,
      });
    }

    const target = new URL(url);

    const allowedHosts = [
      "apexpublicschool.in",
      "www.apexpublicschool.in",
    ];

    if (!allowedHosts.includes(target.hostname)) {
      return new NextResponse("Host not allowed", {
        status: 403,
      });
    }

    const response = await fetch(target.toString(), {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/154 Safari/537.36",
        "Accept":
          "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
        "Referer": "https://apexpublicschool.in/",
      },
      cache: "no-store",
    });

    if (!response.ok) {
      return new NextResponse("Unable to fetch image", {
        status: response.status,
      });
    }

    const contentType =
      response.headers.get("content-type") ||
      "image/jpeg";

    const buffer = await response.arrayBuffer();

    return new NextResponse(buffer, {
      status: 200,
      headers: {
        "Content-Type": contentType,
        "Cache-Control":
          "public, max-age=86400, s-maxage=86400",
      },
    });
  } catch (error) {
    console.error("IMAGE PROXY ERROR:", error);

    return new NextResponse(
      "Image proxy failed",
      { status: 500 }
    );
  }
}
